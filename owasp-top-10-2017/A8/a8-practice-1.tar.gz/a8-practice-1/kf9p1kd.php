<?php
    $flag = "CTF{51mpl3_d353r14l1z3}";
?>
